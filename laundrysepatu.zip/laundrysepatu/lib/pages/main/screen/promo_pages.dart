import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/material.dart';

class PromoPages extends StatelessWidget {
  PromoPages({super.key});

  List promoItem = ["Promo1", "Promo2", "Promo3"];

  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size(double.infinity, 80),
        child: Container(
          margin: EdgeInsets.only(top: statusBarHeight),
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(
            color: Color(0xff357498),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(20),
              bottomRight: Radius.circular(20),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Promo',
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
      body: ListView.builder(
        itemCount: promoItem.length,
        itemBuilder: (context, index) => InkWell(
          onTap: () {},
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
            child: Image.asset('assets/${promoItem[index]}.png'),
          ),
        ),
      ),
    );
  }
}
