import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../login/login_pages.dart';
import 'component/account/customListTile.dart';

class AkunPages extends StatelessWidget {
  const AkunPages({super.key});

  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size(double.infinity, 80),
        child: Padding(
          padding: EdgeInsets.only(top: statusBarHeight),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
              color: Color(0xff357498),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: Row(
              children: [
                Column(
                  children: [
                    Text(
                      'Hi, Jihad Natra S',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Text(
                          '0 Poin',
                          style: GoogleFonts.poppins(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xff357498),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                const Icon(
                  Icons.account_circle_rounded,
                  size: 50,
                  color: Colors.white,
                )
              ],
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
                color: Color(0xff357498),
                borderRadius: BorderRadiusDirectional.all(Radius.circular(20))),
            child: Column(
              children: [
                CustomListTile(
                  icon: Icons.account_circle_outlined,
                  title: 'Akun',
                ),
                CustomListTile(
                  icon: Icons.data_thresholding_outlined,
                  title: 'Riwayat Pemesanan',
                ),
                CustomListTile(
                  icon: Icons.wallet_giftcard_outlined,
                  title: 'NEAT Wallet',
                ),
                CustomListTile(
                  icon: Icons.add_circle_outline_rounded,
                  title: 'Tukar Point',
                ),
                CustomListTile(
                  icon: Icons.chat_outlined,
                  title: 'Kritik & Saran',
                ),
                CustomListTile(
                  icon: Icons.headset_mic_outlined,
                  title: 'Customer Service',
                ),
                TextButton(
                  onPressed: () {
                    // halaman kebijakan dll masuk sini
                  },
                  child: Text(
                    'Baca Kebijakan Privasi dan\nSyarat Ketentuan',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline,
                      color: Colors.white,
                    ),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (context) {
                      return LoginPage();
                    }));
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      vertical: 10,
                      horizontal: 40,
                    ),
                    child: Text(
                      'Logout',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xff357498),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
