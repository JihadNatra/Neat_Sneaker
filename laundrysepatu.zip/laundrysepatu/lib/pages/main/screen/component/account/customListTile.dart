import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CustomListTile extends StatelessWidget {
  CustomListTile({
    super.key,
    required this.icon,
    required this.title,
  });

  IconData icon;
  String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 15),
      child: ListTile(
        onTap: () {
          // masukin fungsinya disini..... pake constructor.
          // jadiin navigator halaman buat ngarahinny
        },
        leading: Icon(
          icon,
          size: 40,
          color: Colors.white,
        ),
        title: Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        trailing: const Icon(
          Icons.arrow_forward_ios_outlined,
          color: Colors.white,
        ),
      ),
    );
  }
}
