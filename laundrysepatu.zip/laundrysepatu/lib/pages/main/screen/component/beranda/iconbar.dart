import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class IconBar extends StatelessWidget {
  IconBar({
    super.key,
    required this.icon,
    required this.title,
  });

  IconData icon;
  String title;

  @override
  Widget build(BuildContext context) {
    return Expanded(
        flex: 1,
        child: InkWell(
          onTap: () {},
          child: Column(
            children: [
              Icon(
                icon,
                size: 30,
                color: Colors.white,
              ),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              )
            ],
          ),
        ));
  }
}
