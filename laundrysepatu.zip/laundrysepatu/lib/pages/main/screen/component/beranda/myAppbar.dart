import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'iconbar.dart';

class MyAppBar extends StatelessWidget {
  const MyAppBar({
    super.key,
    required this.statusBarHeight,
  });

  final double statusBarHeight;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: statusBarHeight),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: const BoxDecoration(
            color: Color(0xff357498),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(20),
              bottomRight: Radius.circular(20),
            )),
        child: Column(
          children: [
            Row(
              children: [
                //logonya 
                Image.asset('assets/LogoK.png', scale: 1.1),
                const SizedBox(width: 5),
                Text(
                  'Hi, Jihad Natra S',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const Spacer(),
                const Icon(
                  Icons.notifications_active_outlined,
                  color: Colors.white,
                ),
                const SizedBox(width: 10),
                const Icon(
                  Icons.chat_outlined,
                  color: Colors.white,
                ),
              ],
            ),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    margin: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Text(
                        '0 Poin',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xff357498),
                        ),
                      ),
                    ),
                  ),
                ),
                IconBar(
                  icon: Icons.star_border_outlined,
                  title: 'Tukar Point',
                ),
                IconBar(
                  icon: Icons.wallet_giftcard_rounded,
                  title: 'Neat Wallet',
                ),
                IconBar(
                  icon: Icons.add_circle_outline_rounded,
                  title: 'Top Up',
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
