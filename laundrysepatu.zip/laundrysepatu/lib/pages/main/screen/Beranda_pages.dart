// ignore_for_file: prefer_const_constructors, file_names

import 'package:google_fonts/google_fonts.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'component/beranda/myAppbar.dart';

// ignore: must_be_immutable
class BerandaPages extends StatelessWidget {
  BerandaPages({super.key});

  // buat loop gambar
  List item = ['FC', 'DC', 'W', 'RL', 'RB', 'RS'];

  List banner = [
    'assets/Slide1.png',
    'assets/Slide1.png',
    'assets/Slide1.png',
  ];

  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: PreferredSize(
        preferredSize: Size(double.infinity, 120),
        child: MyAppBar(statusBarHeight: statusBarHeight),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(5),
          child: Column(
            children: [
              CarouselSlider(
                  items: banner
                      .map((item) => Container(
                            padding: const EdgeInsets.all(5),
                            child: Center(
                              child: Image.asset(
                                //asset ganti ke network kalo mau pake link
                                item,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ))
                      .toList(),
                  options: CarouselOptions(
                    height: 150,
                    aspectRatio: 16 / 9, // ganti sesuai ukuran banner ntar
                    viewportFraction: 0.8,
                    initialPage: 0,
                    enableInfiniteScroll: true,
                    reverse: false,
                    autoPlay: true,
                    autoPlayInterval: Duration(seconds: 3),
                    autoPlayAnimationDuration: Duration(milliseconds: 800),
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enlargeCenterPage: true,
                    enlargeFactor: 0.3,
                    scrollDirection: Axis.horizontal,
                  )),
              GridView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2),
                itemCount: item.length,
                itemBuilder: (context, index) => InkWell(
                  onTap: () {
                    // fungsinya masukin sendiri
                  },
                  child: Image.asset('assets/${item[index]}.png'),
                ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Promo spesial untukmu',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 5),
                      child: Image.asset('assets/spesial.png'),
                    ),
                    Text(
                      'Pesan Sekarang, Cuci 2 Gratis 1',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
