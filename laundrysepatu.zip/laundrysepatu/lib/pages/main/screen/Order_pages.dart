import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'component/order/orderCard.dart';

class OrderPages extends StatefulWidget {
  const OrderPages({super.key});

  @override
  State<OrderPages> createState() => _OrderPagesState();
}

class _OrderPagesState extends State<OrderPages> {
  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size(double.infinity, 80),
          child: Container(
            margin: EdgeInsets.only(top: statusBarHeight),
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Color(0xff357498),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Order',
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
        body: Column(
          children: [
            TabBar(tabs: [
              Tab(
                  child: Text(
                'Pesanan',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey,
                ),
              )),
              Tab(
                  child: Text(
                'Riwayat',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey,
                ),
              )),
            ]),
            Expanded(
              child: TabBarView(
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  // tabbar bagian pemesanan
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        OrderCard(
                          image: 'assets/RS.png',
                          categoryTitle: 'Fast Clean',
                          inOrder: true,
                        ),
                        OrderCard(
                          image: 'assets/DC.png',
                          categoryTitle: 'Deep Clean',
                          inOrder: true,
                        ),
                      ],
                    ),
                  ),
                  // tabbar bagian Riwayat
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        OrderCard(
                          image: 'assets/RB.png',
                          categoryTitle: 'Repaint Bots',
                          inOrder: false,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
