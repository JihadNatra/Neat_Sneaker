package com.example.laundrysepatu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
